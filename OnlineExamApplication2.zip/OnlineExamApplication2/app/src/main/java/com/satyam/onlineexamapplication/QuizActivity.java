package com.satyam.onlineexamapplication;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class QuizActivity extends AppCompatActivity implements View.OnClickListener {

    FirebaseDatabase db;
    DatabaseReference reference;

    TextView totalQuestion, questionTxt;
    Button ansA, ansB, ansC, ansD, submitBtn;



    int score = 0;
    int totalQues = QuestionAnswer.question.length;
    int currentQuestion = 0;
    String selectedAnswer = "";

    String userName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz);

        // Retrieve the user's name from the intent
        userName = getIntent().getStringExtra("user_name");





        totalQuestion = findViewById(R.id.totalQuestion);
        questionTxt = findViewById(R.id.questionTxt);
        ansA = findViewById(R.id.ansA);
        ansB = findViewById(R.id.ansB);
        ansC = findViewById(R.id.ansC);
        ansD = findViewById(R.id.ansD);
        submitBtn = findViewById(R.id.submitBtn);

        ansA.setOnClickListener(this);
        ansB.setOnClickListener(this);
        ansC.setOnClickListener(this);
        ansD.setOnClickListener(this);
        submitBtn.setOnClickListener(this);

        totalQuestion.setText("Total Question : " + totalQues);

        loadNewQuestion();
    }

    @Override
    public void onClick(View v) {
        ansA.setBackgroundColor(Color.GRAY);
        ansA.setBackgroundResource(R.drawable.buttonshape);
        ansB.setBackgroundColor(Color.GRAY);
        ansB.setBackgroundResource(R.drawable.buttonshape);

        ansC.setBackgroundColor(Color.GRAY);
        ansC.setBackgroundResource(R.drawable.buttonshape);

        ansD.setBackgroundColor(Color.GRAY);
        ansD.setBackgroundResource(R.drawable.buttonshape);


        Button clickButton = (Button) v;

        if (clickButton == submitBtn) {
            if (selectedAnswer.equals(QuestionAnswer.correctAnswer[currentQuestion])) {
                score++;
            }
            currentQuestion++;
            loadNewQuestion();
        } else {
            selectedAnswer = clickButton.getText().toString();
            clickButton.setBackgroundColor(Color.MAGENTA);

            UserAnswer userAnswer = new UserAnswer(selectedAnswer);
            db = FirebaseDatabase.getInstance();

            reference =db.getReference("Quiz of "+ userName );
            // Save the user's selected answer to the Firebase database
            reference.child("Answer " + currentQuestion).setValue(userAnswer);
        }
    }

    void loadNewQuestion() {
        if (currentQuestion == totalQues) {
            finishQuiz();
            return;
        }
        questionTxt.setText(QuestionAnswer.question[currentQuestion]);

        // Check if currentQuestion is within the valid range for choices
        if (currentQuestion < 0 || currentQuestion >= QuestionAnswer.choice.length) {
            ansA.setText("");
            ansB.setText("");
            ansC.setText("");
            ansD.setText("");
        } else {
            ansA.setText(QuestionAnswer.choice[currentQuestion][0]);
            ansB.setText(QuestionAnswer.choice[currentQuestion][1]);
            ansC.setText(QuestionAnswer.choice[currentQuestion][2]);
            ansD.setText(QuestionAnswer.choice[currentQuestion][3]);
        }
    }

    void finishQuiz() {
        String passStatus = "";
        if (score > totalQues * 0.6) {
            passStatus = "PASSED";
        } else {
            passStatus = "FAILED";
        }

        new AlertDialog.Builder(this).setTitle(passStatus)
                .setMessage("Score is: " + score + " Out Of " + totalQues)
                .show();
    }
}