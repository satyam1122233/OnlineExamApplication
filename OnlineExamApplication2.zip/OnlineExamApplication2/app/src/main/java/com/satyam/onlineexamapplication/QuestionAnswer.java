package com.satyam.onlineexamapplication;

public class QuestionAnswer {



        public static String question[] = {
                "Question 1. What does CPU stand for ?", "Question 2. What is the full form of RAM ?",
                "Question 3. Which device is used to input data into a computer ?",
                "Question 4. Which component of a computer is responsible for storing data permanently ?"
                ,"Question 5.Which of the following is a programming language ?"
        };

        public static String choice[][] = {
                {"A. Computer Processing Unit", "B. Central Processing Uni", "C. Computer Processing User", "D. Central Processing User"},
                {"A. Random Access Memory", "B. Read Access Memory", "C. Random Authorization Memory", "D. Read Authorization Memory"},
                {"A. Monitor", "B. Printer", "C. Keyboard", "D. Speaker"},
                {"A. RAM", "B. CPU", "C. Hard Disk", "D. CD-ROM"},
                {"A. Java", "B. Monitor", "C. Keyboard", "D. Printer"}




        };


        public static String correctAnswer[] = {
                "B. Central Processing Uni","A. Random Access Memory","C. Keyboard","C. Hard Disk","A. Java"

        };

    }


