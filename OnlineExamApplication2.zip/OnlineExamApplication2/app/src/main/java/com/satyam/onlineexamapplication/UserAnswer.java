package com.satyam.onlineexamapplication;

public class UserAnswer {
    private String selectedAnswer;

    public UserAnswer() {
        // Required empty constructor for Firebase
    }

    public UserAnswer(String selectedAnswer) {
        this.selectedAnswer = selectedAnswer;
    }

    public String getSelectedAnswer() {
        return selectedAnswer;
    }

    public void setSelectedAnswer(String selectedAnswer) {
        this.selectedAnswer = selectedAnswer;
    }
}
