package com.satyam.onlineexamapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;



public class MainActivity extends AppCompatActivity {


    Button startBtn;
    EditText nameTxt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        startBtn = findViewById(R.id.startBtn);
        nameTxt = findViewById(R.id.nameTxt);

        startBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = nameTxt.getText().toString(); // Get the name when the button is clicked
                if (!name.isEmpty()) {
                    // Initialize Firebase Database

                    // Start the QuizActivity
                    Intent intent = new Intent(MainActivity.this, QuizActivity.class);
                    intent.putExtra("user_name", name);
                    startActivity(intent);
                } else {
                    Toast.makeText(MainActivity.this, "Please Provide Your Name", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
